<?php require('partials/head.php'); ?>

    <h1>Sprawdzamy gitaaaa></h1>

<?php require('partials/footer.php'); ?>
