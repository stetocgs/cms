<?php require('partials/head.php'); ?>

    <h1>Our Culture at <?= $name ?? ''; ?></h1>

<?php require('partials/footer.php'); ?>
