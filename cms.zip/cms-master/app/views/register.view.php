<?php require('partials/head.php'); ?>


<?php if(session_status () == PHP_SESSION_ACTIVE && !isset($_SESSION['my_data'])): ?>

<h1>Register to our service</h1>

<?= $userMessage ?? ''; ?>
<form method="POST" action="/register">
    <b>Username [1-32]: </b> <br><input name="username" >
    <br><b>Password [1-32]: </b> <br><input name="password" type="password">
    <br><b>Repeat password [1-32]: </b> <br><input name="password_rep" type="password">
    <br><b>Email: </b>    <br><input name="email" type="email">
    <br><br><button type="submit">Register</button>
    <input type="reset">
</form>

<?php endif; ?>

<?php require('partials/footer.php'); ?>





