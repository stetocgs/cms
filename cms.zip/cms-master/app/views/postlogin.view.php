<?php require('partials/head.php'); ?>


<h1><?= $loginStatus ?? ''; ?></h1>

<?php require('partials/footer.php'); ?>



